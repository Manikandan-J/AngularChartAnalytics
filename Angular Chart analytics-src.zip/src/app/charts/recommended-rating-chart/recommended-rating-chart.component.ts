import { Component, OnInit } from '@angular/core';
import { ChartOptions, ChartType } from 'chart.js';
import { Color, Label, SingleDataSet } from 'ng2-charts';
import { ChartDataService } from 'src/app/service/chart-data.service';

@Component({
  selector: 'app-recommended-rating-chart',
  templateUrl: './recommended-rating-chart.component.html',
  styleUrls: ['./recommended-rating-chart.component.css']
})
export class RecommendedRatingChartComponent implements OnInit {

  public pieChartOptions: ChartOptions = {
    responsive: true,
  };
  public pieChartLabels: Label[] = ['5 Stars', '4 Stars', '3 Stars', '2 Stars', '1 Star'];
  public pieChartData: SingleDataSet = [28, 35, 25, 7, 5];
  public pieChartType: ChartType = 'pie';
  public pieChartLegend = true;
  public pieChartPlugins = [];

  pieChartColors:any = [
    {
        borderColor: 'black',
        borderWidth: 1,
        backgroundColor: ['Aqua',
        'GreenYellow',
        'Orange',
        'Fuchsia',
        'RoyalBlue'
        ]
    }
];  

  constructor(public chartDataService: ChartDataService) { }

  ngOnInit() {
    this.chartDataService.currentRatingData.subscribe((data)=>
    {
      this.pieChartData = data.slice();
    })
  }

}
