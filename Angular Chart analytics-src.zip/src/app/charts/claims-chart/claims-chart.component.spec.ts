import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClaimsChartComponent } from './claims-chart.component';

describe('ClaimsChartComponent', () => {
  let component: ClaimsChartComponent;
  let fixture: ComponentFixture<ClaimsChartComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClaimsChartComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClaimsChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
