import { ChartsModule } from 'ng2-charts';
import { NgModule } from '@angular/core';
import { ClaimsChartComponent } from './claims-chart.component';

@NgModule({
    declarations: [
        ClaimsChartComponent
    ],
    imports: [
        ChartsModule
    ],
    providers: [],
    bootstrap: [ClaimsChartComponent]
})
export class ClaimsChartModule {}