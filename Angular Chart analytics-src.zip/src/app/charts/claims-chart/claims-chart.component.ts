import { Component, OnDestroy, OnInit } from '@angular/core';
import { ChartDataSets, ChartOptions, ChartType } from 'chart.js';
import { Color, Label } from 'ng2-charts';
import { ChartDataService } from 'src/app/service/chart-data.service';

@Component({
  selector: 'app-claims-chart',
  templateUrl: './claims-chart.component.html',
  styleUrls: ['./claims-chart.component.css']
})
export class ClaimsChartComponent implements OnInit{
  value1: number=75;
  public barChartOptions: ChartOptions = {
    responsive: true,
  };
  public barChartLabels: Label[] = [];
  public barChartType: ChartType = 'bar';
  public barChartLegend = true;
  public barChartPlugins = [];
 
  public barChartData: ChartDataSets[] = [
    { data: [], label: 'Claims %', borderWidth: 1 }
   
  ];
  
  

  public barChartColors: Color[] = [
    {
      borderColor: 'black',    
      backgroundColor: 'Maroon',
    }
  ];

  constructor(private chartDataService: ChartDataService) { }
  

  ngOnInit() {
   
  

    this.chartDataService.currentClaimsData.subscribe(data  => {
     this.barChartData[0].data = data.slice();
    });
    this.chartDataService.currentClaimsLabel.subscribe((data)=>
    {
      this.barChartLabels = data.slice();
    });
    }

}
