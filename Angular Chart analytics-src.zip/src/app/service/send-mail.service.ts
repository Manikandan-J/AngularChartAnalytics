import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SendMailService {

  baseUrl = 'http://localhost:8080';
  constructor(private http: HttpClient) { }
  searchLOB(targetLOB: string,targetState: string):Observable<any>
  {
    return this.http.get<any>(`${this.baseUrl}/searchLOB/${targetLOB}/${targetState}`);
  }
  sendMail(sourceLOB: string,sourceState: string,targetLOB: string,targetState: string):Observable<any>
  {
    return this.http.get<any>(`${this.baseUrl}/sendMail/${sourceLOB}/${sourceState}/${targetLOB}/${targetState}`);
  }
}
