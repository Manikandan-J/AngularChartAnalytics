import { TestBed } from '@angular/core/testing';

import { CustomerResponseService } from './customer-response.service';

describe('CustomerResponseService', () => {
  let service: CustomerResponseService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CustomerResponseService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
