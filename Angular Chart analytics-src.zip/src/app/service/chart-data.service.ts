import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { ChartData } from '../Model/ChartData';

@Injectable({
  providedIn: 'root'
})
export class ChartDataService {

/* REST API MAPPING */

  baseUrl = 'http://localhost:8080';

  constructor(private http: HttpClient) { }

  getChartData(): Observable<ChartData>
  {
     return this.http.get<any>(`${this.baseUrl}/getChartData`);

  }

  
/**
 * Chart Data Setters and Getters
 * */ 

 /* Claims Chart Components Data and Label */

private claimsData: BehaviorSubject<number[]>= new BehaviorSubject([0]);
currentClaimsData = this.claimsData.asObservable();
setClaimsData(data: number[])
{
  this.claimsData.next(data);
}

private claimsLabel: BehaviorSubject<string[]>= new BehaviorSubject(['']);
currentClaimsLabel = this.claimsLabel.asObservable();
setClaimslabel(data: string[])
{
  this.claimsLabel.next(data);
}

 /* Product Sales Chart Components Data and Label */

 private productSalesData: BehaviorSubject<number[]>= new BehaviorSubject([0]);
 currentProductSalesData = this.productSalesData.asObservable();
 setProductSalesData(data: number[])
 {
   this.productSalesData.next(data);
 }
 
 private productSalesLabel: BehaviorSubject<string[]>= new BehaviorSubject(['']);
 currentProductSalesLabel = this.productSalesLabel.asObservable();
 setProductSalesLabel(data: string[])
 {
   this.productSalesLabel.next(data);
 }


 /* Product Sales Chart Components Data and Label */

 private yearlySalesData: BehaviorSubject<number[]>= new BehaviorSubject([0]);
 currentyearlySalesData = this.yearlySalesData.asObservable();
 setYearlySalesData(data: number[])
 {
   this.yearlySalesData.next(data);
 }
 
 private yearlySalesLabel: BehaviorSubject<string[]>= new BehaviorSubject(['']);
 currentYearlySalesLabel = this.yearlySalesLabel.asObservable();
 setYearlySalesLabel(data: string[])
 {
   this.yearlySalesLabel.next(data);
 }

  /* Product Sales Chart Components Data and Label */

  private ratingData: BehaviorSubject<number[]>= new BehaviorSubject([0]);
  currentRatingData = this.ratingData.asObservable();
  setRatingData(data: number[])
  {
    this.ratingData.next(data);
  }



}
