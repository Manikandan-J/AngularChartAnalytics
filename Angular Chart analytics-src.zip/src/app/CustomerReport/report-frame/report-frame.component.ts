import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-report-frame',
  templateUrl: './report-frame.component.html',
  styleUrls: ['./report-frame.component.css']
})
export class ReportFrameComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
