import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataServiceService } from 'src/app/service/data-service.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  role: string = '';
  targetLOB: string = '';
  targetState: string = '';

  constructor(private dataService: DataServiceService,private router: Router) { 

        
  }

  ngOnInit(): void {
    this.dataService.currentRole.subscribe(role => this.role =role);
    console.log("role"+this.role)
    this.dataService.currentTargetLOB.subscribe(data => this.targetLOB =data);
    this.dataService.currentTargetState.subscribe(data => this.targetState =data);
    console.log("from nav bar"+this.targetLOB)
  }
  showReport()
  {
    
    this.router.navigate(['/customer-report/analysis/:lob/:state',{lob:this.targetLOB,state :this.targetState}]);
    console.log(this.targetLOB+"From report Method")
  }

}
