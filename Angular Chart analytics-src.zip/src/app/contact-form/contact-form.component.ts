import { Component, OnInit, HostListener } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CustomerResponse } from '../Model/CustomerResponse';
import { CustomerResponseService } from '../service/customer-response.service';
import { DataServiceService } from '../service/data-service.service';

@Component({
  selector: 'app-contact-form',
  templateUrl: './contact-form.component.html',
  styleUrls: ['./contact-form.component.css']
})
export class ContactFormComponent implements OnInit {
 
  contactForm: FormGroup;
  contactName: string = '';
  mail: string = '';
  subject: string = '';
  message: string = '';
  disabledSubmitButton: boolean = true;
  optionsSelect: Array<any>;
  successMsg: boolean = false;
  
    @HostListener('input') oninput() {
  
    if (this.contactForm.valid) {
      this.disabledSubmitButton = false;
      }
    }
  
    constructor(private fb: FormBuilder,private dataService: DataServiceService,private customerResponse: CustomerResponseService ) {
      this.optionsSelect = [];
  
      this.contactForm = fb.group({
        'contactFormName': ['', Validators.required],
        'contactFormEmail': ['', Validators.compose([Validators.required, Validators.email])],
        'contactFormSubjects': ['', Validators.required],
        'contactFormMessage': ['', Validators.required],
        'contactFormCopy': [''],
      });
    }
    ngOnInit(): void{



    }
  
    onSubmit() {

      let response = new CustomerResponse(this.contactName,this.mail,this.subject,this.message)
      console.log("lllllll"+ this.message + response.message);
      this.customerResponse.saveCustomerResponse(response).subscribe(data => 
        {
          console.log("Customer Response Saved"+ data);
        })
      this.successMsg = true;

    }

}
