import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { ChartsModule } from 'ng2-charts';
import { DashComponent } from './dash/dash.component';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatCardModule } from '@angular/material/card';
import { MatMenuModule } from '@angular/material/menu';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatToolbarModule } from '@angular/material/toolbar';
import { LayoutModule } from '@angular/cdk/layout';
import { CardComponent } from './card/card.component';
import { ProductSalesChartComponent } from './charts/product-sales-chart/product-sales-chart.component';
import { RecommendedRatingChartComponent } from './charts/recommended-rating-chart/recommended-rating-chart.component';
import { YearlySalesChartComponent } from './charts/yearly-sales-chart/yearly-sales-chart.component';
import { ClaimsChartComponent } from './charts/claims-chart/claims-chart.component';
//import { TopCommentsTableComponent } from './top-comments-table/top-comments-table.component';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { FormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field'
import { MatInputModule } from '@angular/material/input';
import { HeaderComponent } from './dashboard/common/header/header.component';
import { LoginComponent } from './dashboard/common/login/login.component';
import { EmailAcknowlwdgeComponent } from './dashboard/common/email-acknowlwdge/email-acknowlwdge.component';
import { FrameComponent } from './dashboard/frame/frame.component';
import { InputLobDetailsComponent } from './dashboard/pages/input-lob-details/input-lob-details.component';
import { LobDataComponent } from './dashboard/pages/lob-data/lob-data.component';
import { HttpClientModule } from '@angular/common/http';
import { ReportFrameComponent } from './CustomerReport/report-frame/report-frame.component';
import { NavbarComponent } from './CustomerReport/navbar/navbar.component';
import { ContactFormComponent } from './contact-form/contact-form.component';
import { ChartsCarouselComponent } from './charts-carousel/charts-carousel.component';
import { ReactiveFormsModule  } from '@angular/forms';
import { MDBBootstrapModule } from 'angular-bootstrap-md';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CarouselModule } from 'ngx-bootstrap/carousel';
import { DataServiceService } from 'src/app/service/data-service.service';
@NgModule({
  declarations: [
    AppComponent,
    DashComponent,
    CardComponent,
    ProductSalesChartComponent,
    RecommendedRatingChartComponent,
    YearlySalesChartComponent,
    ClaimsChartComponent,
    HeaderComponent,
    LoginComponent,
    EmailAcknowlwdgeComponent,
    FrameComponent,
    InputLobDetailsComponent,
    LobDataComponent,
    ReportFrameComponent,
    NavbarComponent,
    ContactFormComponent,
    ChartsCarouselComponent,
    
    
    //TopCommentsTableComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NoopAnimationsModule,
    ChartsModule,
    MatGridListModule,
    MatCardModule,
    MatMenuModule,
    MatToolbarModule,
    MatIconModule,
    MatButtonModule,
    LayoutModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    FormsModule,
    MatFormFieldModule,
    MatInputModule,
    HttpClientModule,
    ReactiveFormsModule,
    MDBBootstrapModule,
    NgbModule,
    CarouselModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
