import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashComponent } from './dash/dash.component';
import { ClaimsChartComponent } from './charts/claims-chart/claims-chart.component';
import { LoginComponent } from './dashboard/common/login/login.component';
import { FrameComponent } from './dashboard/frame/frame.component';
import { InputLobDetailsComponent } from './dashboard/pages/input-lob-details/input-lob-details.component';
import { LobDataComponent } from './dashboard/pages/lob-data/lob-data.component';
import { EmailAcknowlwdgeComponent } from './dashboard/common/email-acknowlwdge/email-acknowlwdge.component';
import { ReportFrameComponent } from './CustomerReport/report-frame/report-frame.component';
import { ContactFormComponent } from './contact-form/contact-form.component';

const routes: Routes = [
  { path: '', redirectTo: '/Dashboard/login', pathMatch: 'full' },
  { path: 'Dashboard', component: FrameComponent,
    children:[
      {path:'login',component: LoginComponent},
      {path: 'LOB-Inputs',component: InputLobDetailsComponent},
      {path: 'LOB-Analysis-report',component: LobDataComponent},
      {path: 'Mail-triggered',component: EmailAcknowlwdgeComponent},

    ]
},
  
  { path: 'customer-report', component: ReportFrameComponent,
  children:[
    {path:'analysis',component: DashComponent},
    {path:'analysis/:lob/:state',component: DashComponent},
    {path:'contact',component: ContactFormComponent}
  ]
  
},
  {path: '**',redirectTo: '/Dashboard/login', pathMatch: 'full'}
                        ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
