import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-email-acknowlwdge',
  templateUrl: './email-acknowlwdge.component.html',
  styleUrls: ['./email-acknowlwdge.component.css']
})
export class EmailAcknowlwdgeComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit(): void {
  }
  searchLob()
  {
    this.router.navigate(['/Dashboard/LOB-Inputs']);

  }
  logOff()
  {
    this.router.navigate(['']);
  }

}
