import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmailAcknowlwdgeComponent } from './email-acknowlwdge.component';

describe('EmailAcknowlwdgeComponent', () => {
  let component: EmailAcknowlwdgeComponent;
  let fixture: ComponentFixture<EmailAcknowlwdgeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmailAcknowlwdgeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmailAcknowlwdgeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
