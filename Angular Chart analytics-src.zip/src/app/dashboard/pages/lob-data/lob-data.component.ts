import { Component, OnInit } from '@angular/core';
import { DataServiceService } from 'src/app/service/data-service.service';
import { Router } from '@angular/router';
import { SendMailService } from 'src/app/service/send-mail.service';
import { LOBAnalysisData } from 'src/app/Model/LOBAnlaysisData';
@Component({
  selector: 'app-lob-data',
  templateUrl: './lob-data.component.html',
  styleUrls: ['./lob-data.component.css']
})
export class LobDataComponent implements OnInit {

  constructor(private router: Router,private dataService: DataServiceService,private mailService: SendMailService) { }
  role: string = '';
  show: boolean = true;
  targetState: string = '';
  targetLOB: string = '';
  sourceState: string = '';
  sourceLOB: string = '';
//  lobData: LOBAnalysisData = new LOBAnalysisData('',0,0,0,0,0);
  //  lobData: LOBAnalysisData = new LOBAnalysisData('',0,0,0,0,0);
  lobData: LOBAnalysisData = new LOBAnalysisData('',0,0,0,0,0);
  lobData1!: LOBAnalysisData;
//   perPolicyGrowth: number = 0;
//  perRenewal: number = 0;
//  perClaims: number = 0;
//  perNewCustomer: number = 0;
//  avgRating: number =0;
  ngOnInit(): void {
    this.dataService.currentRole.subscribe(role => this.role =role);
    
    this.dataService.currentTargetLOB.subscribe(targetLOB =>this.targetLOB = targetLOB);
    this.dataService.currentTargetState.subscribe(targetState => this.targetState = targetState);
    this.dataService.currentSourceLOB.subscribe(data => this.sourceLOB = data);
    this.dataService.currentSourceState.subscribe(data => this.sourceState = data);
    if(this.targetState !=null && this.targetLOB != null)
    {
    this.mailService.searchLOB(this.targetLOB,this.targetState).subscribe(data =>this.lobData = data);
    // this.dataService.setLOBData(this.lobData);
   // this.dataService.currentLOBData.subscribe(data =>this.lobData1 = data)
    //  this.perNewCustomer = this.lobData.perNewCustomer;
    //  this.perPolicyGrowth = this.lobData.perPolicyGrowth;
    //  this.perClaims = this.lobData.perClaims;
    //  this.perRenewal = this.lobData.perRenewal;
    
    }

  }
  searchLob()
  {
    this.router.navigate(['/Dashboard/LOB-Inputs']);
  }
  logOff()
  {
    this.router.navigate(['']);
  }
  triggerMail()
  {

    // this.filterService.getSearchFilterData(this.role,this.location).subscribe(response => this.search=response);
    this.mailService.sendMail(this.sourceLOB,this.sourceState,this.targetLOB,this.targetState).subscribe();
    
    this.router.navigate(['/Dashboard/Mail-triggered']);
  }
  showUI()
  {
    // this.router.navigate(['/customer-report/analysis/:lob/:state',{lob: this.targetLOB,state :this.targetState}]);
    this.router.navigate([]).then(result => {  window.open( `/customer-report/analysis/${this.targetLOB}/${this.targetState}`, '_blank'); });

  }
 

}
