import { Component, OnInit } from '@angular/core';
import { ChartData } from '../Model/ChartData';
import { ChartDataService } from '../service/chart-data.service';

@Component({
  selector: 'app-charts-carousel',
  templateUrl: './charts-carousel.component.html',
  styleUrls: ['./charts-carousel.component.css']
})
export class ChartsCarouselComponent implements OnInit {

  constructor(private chartDataService: ChartDataService) { }
   
  // chartData: ChartData = new ChartData(['2015'],[25],['2016'],[45],['2017'],[45],[6]);
   // chartData: ChartData = new ChartData(['2015'],[25],['2016'],[45],['2017'],[45],[6]);
   chartData!: ChartData; 
   claimsData: number[] = [];
  // chartData: ChartData;
  
  // setClaimsData(data: number[]): void
  // {
  //     this.claimsData = data.slice();
  //     console.log('ClaimsData'+this.claimsData);
  // }
  ngOnInit(): void {

    let data = new ChartData(['a','b','c'],[1,2,3],['d','e','f'],[4,5,6],['g','h','i'],[7,8,9],[0,0,0]);
    this.chartDataService.getChartData().subscribe((data: ChartData )=> 
      {
        //this.chartData = new ChartData(data.claimsYear,data.claimsData,data.productSalesYear,data.prodcutSalesData,data.yearlySalesMonth,data.yearlySalesData,data.ratingData);
  // this.setClaimsData(data.claimsData);
          // this.claimsData = data.claimsData.slice();
         this.chartDataService.setClaimsData(data.claimsData);
         this.chartDataService.setClaimslabel(data.claimsYear);
         this.chartDataService.setProductSalesData(data.prodcutSalesData);
         this.chartDataService.setProductSalesLabel(data.productSalesYear);
         this.chartDataService.setYearlySalesData(data.yearlySalesData);
         this.chartDataService.setYearlySalesLabel(data.yearlySalesMonth);
         this.chartDataService.setRatingData(data.ratingData);
        
        
      });
       
    
  }
 
  ngOnDetsroy()
  {

  }
}
