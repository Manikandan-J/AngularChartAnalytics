package com.cts.gic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GicInsStsAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(GicInsStsAppApplication.class, args);
		System.out.println("**********GIC App Started*************");
	}

}
