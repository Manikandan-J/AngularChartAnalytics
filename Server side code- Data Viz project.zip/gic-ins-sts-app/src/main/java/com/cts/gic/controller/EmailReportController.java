package com.cts.gic.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.gic.customer.service.CustomerService;
import com.cts.gic.email.service.SendEmailService;


import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class EmailReportController {
	
	@Autowired
	CustomerService customerService;
	
	@Autowired
	SendEmailService SendEmailService;
	
	
	@GetMapping(value = "/sendMail/{sourceLOB}/{sourceState}/{targetLOB}/{targetState}")
    public String sendEmailReport(@PathVariable("sourceLOB") String sourceLOB,@PathVariable("sourceState") String sourceState,@PathVariable("targetLOB") String targetLOB,@PathVariable("targetState") String targetState) {
		System.out.println("incontroller");
		String emailList = customerService.getCustomerDetailsforLOBandState(sourceLOB, sourceState);
		System.out.println();
		//get built UI from frontend using rest call
		String URL = "http:localhost:4200"+"/"+targetLOB+"/"+targetState;
		
        return SendEmailService.sendEmailReport(emailList, URL);
    }
}
