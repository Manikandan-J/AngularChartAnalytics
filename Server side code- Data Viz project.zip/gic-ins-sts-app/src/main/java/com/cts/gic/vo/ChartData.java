package com.cts.gic.vo;

import java.util.ArrayList;

public class ChartData {

	
	ArrayList<Integer> claimsData;
	ArrayList<String> claimsYear;
	ArrayList<String> productSalesYear;
	ArrayList<Integer> prodcutSalesData;
	ArrayList<String> yearlySalesMonth;
	ArrayList<Integer> yearlySalesData;
	ArrayList<Integer> ratingData;
	
	
	
	public ChartData() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ChartData(ArrayList<String> claimsYear, ArrayList<Integer> claimsData, ArrayList<String> productSalesYear,
			ArrayList<Integer> prodcutSalesData, ArrayList<String> yearlySalesMonth, ArrayList<Integer> yearlySalesData,
			ArrayList<Integer> ratingData) {
		super();
		this.claimsYear = claimsYear;
		this.claimsData = claimsData;
		this.productSalesYear = productSalesYear;
		this.prodcutSalesData = prodcutSalesData;
		this.yearlySalesMonth = yearlySalesMonth;
		this.yearlySalesData = yearlySalesData;
		this.ratingData = ratingData;
	}

	public ArrayList<String> getClaimsYear() {
		return claimsYear;
	}

	public void setClaimsYear(ArrayList<String> claimsYear) {
		this.claimsYear = claimsYear;
	}

	public ArrayList<Integer> getClaimsData() {
		return claimsData;
	}

	public void setClaimsData(ArrayList<Integer> claimsData) {
		this.claimsData = claimsData;
	}

	public ArrayList<String> getProductSalesYear() {
		return productSalesYear;
	}

	public void setProductSalesYear(ArrayList<String> productSalesYear) {
		this.productSalesYear = productSalesYear;
	}

	public ArrayList<Integer> getProdcutSalesData() {
		return prodcutSalesData;
	}

	public void setProdcutSalesData(ArrayList<Integer> prodcutSalesData) {
		this.prodcutSalesData = prodcutSalesData;
	}

	public ArrayList<String> getYearlySalesMonth() {
		return yearlySalesMonth;
	}

	public void setYearlySalesMonth(ArrayList<String> yearlySalesMonth) {
		this.yearlySalesMonth = yearlySalesMonth;
	}

	public ArrayList<Integer> getYearlySalesData() {
		return yearlySalesData;
	}

	public void setYearlySalesData(ArrayList<Integer> yearlySalesData) {
		this.yearlySalesData = yearlySalesData;
	}

	public ArrayList<Integer> getRatingData() {
		return ratingData;
	}

	public void setRatingData(ArrayList<Integer> ratingData) {
		this.ratingData = ratingData;
	}

	@Override
	public String toString() {
		return "ChartData [claimsYear=" + claimsYear + ", claimsData=" + claimsData + ", productSalesYear="
				+ productSalesYear + ", prodcutSalesData=" + prodcutSalesData + ", yearlySalesMonth=" + yearlySalesMonth
				+ ", yearlySalesData=" + yearlySalesData + ", ratingData=" + ratingData + "]";
	}
}
