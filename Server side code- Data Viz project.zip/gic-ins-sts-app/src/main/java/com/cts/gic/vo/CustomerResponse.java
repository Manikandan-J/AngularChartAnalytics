package com.cts.gic.vo;

import lombok.Data;
import lombok.Getter;

@Getter
@Data
public class CustomerResponse {

	private String contactName;
	private String mail;
	private String subject;
	private String message;
	@Override
	public String toString() {
		return "CustomerResponse [contactName=" + contactName + ", mail=" + mail + ", subject=" + subject + ", message="
				+ message + "]";
	}
	public CustomerResponse() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CustomerResponse(String contactName, String mail, String subject, String message) {
		super();
		this.contactName = contactName;
		this.mail = mail;
		this.subject = subject;
		this.message = message;
	}
	public String getContactName() {
		return contactName;
	}
	public void setContactName(String contactName) {
		this.contactName = contactName;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	

}
