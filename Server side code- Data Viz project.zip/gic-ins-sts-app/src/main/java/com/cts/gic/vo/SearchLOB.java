package com.cts.gic.vo;

import lombok.Data;

@Data
public class SearchLOB {

	private String lob;
	private double perPolicyGrowth;
	private double perRenewal;
	private double perClaims;
	private double perNewCustomer;
	private double avgRating;

	public SearchLOB() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SearchLOB(String lob, double perPolicyGrowth, double perRenewal, double perClaims, double perNewCustomer,
			double avgRating) {
		super();
		this.lob = lob;
		this.perPolicyGrowth = perPolicyGrowth;
		this.perRenewal = perRenewal;
		this.perClaims = perClaims;
		this.perNewCustomer = perNewCustomer;
		this.avgRating = avgRating;

	}

	public String getLob() {
		return lob;
	}

	public void setLob(String lob) {
		this.lob = lob;
	}

	public double getPerPolicyGrowth() {
		return perPolicyGrowth;
	}

	public void setPerPolicyGrowth(double perPolicyGrowth) {
		this.perPolicyGrowth = perPolicyGrowth;
	}

	public double getPerRenewal() {
		return perRenewal;
	}

	public void setPerRenewal(double perRenewal) {
		this.perRenewal = perRenewal;
	}

	public double getPerClaims() {
		return perClaims;
	}

	public void setPerClaims(double perClaims) {
		this.perClaims = perClaims;
	}

	public double getPerNewCustomer() {
		return perNewCustomer;
	}

	public void setPerNewCustomer(double perNewCustomer) {
		this.perNewCustomer = perNewCustomer;
	}

	public double getAvgRating() {
		return avgRating;
	}

	public void setAvgRating(double avgRating) {
		this.avgRating = avgRating;
	}

}
