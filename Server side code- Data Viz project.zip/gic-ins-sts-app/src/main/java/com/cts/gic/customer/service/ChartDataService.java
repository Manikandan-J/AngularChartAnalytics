package com.cts.gic.customer.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.gic.vo.ChartData;

@Service
public class ChartDataService {
	
	
	
	public ChartData getChartData()
	{
		
		ChartData chartData = new ChartData();
		
		
		ArrayList<Integer> claimsDataList = new ArrayList<Integer>();
		ArrayList<String>  claimsLabelList = new ArrayList<String>();
		
		ArrayList<Integer> productSalesDataList = new ArrayList<Integer>();
		ArrayList<String> productSalesLabelList = new ArrayList<String>();
		
		ArrayList<Integer> yearlySalesDataList = new ArrayList<Integer>();
		ArrayList<String>  yearlySalesLabelList = new ArrayList<String>();
		
		ArrayList<Integer> ratingDataList = new ArrayList<Integer>();
		
		List<Integer> claimsData,productSalesData,yearlySalesData,ratingData;
		List<String>  claimsLabel,productSalesLabel,yearlySalesLabel; 
		claimsData = Arrays.asList(48,25, 27, 23, 36, 28, 40);
		claimsDataList.addAll(claimsData);
	    chartData.setClaimsData(claimsDataList);
	    productSalesData = Arrays.asList(70, 65, 60, 68, 70, 73, 65);
	    productSalesDataList.addAll(productSalesData);
		chartData.setProdcutSalesData(productSalesDataList);
		yearlySalesData = Arrays.asList(55, 59, 67, 65, 60, 65, 72,80);
		yearlySalesDataList.addAll(yearlySalesData);
		chartData.setYearlySalesData(yearlySalesDataList);
		claimsLabel = Arrays.asList("2014","2015","2016","2017","2018","2019","2020");
		claimsLabelList.addAll(claimsLabel);
		chartData.setClaimsYear(claimsLabelList);
		chartData.setProductSalesYear(claimsLabelList);
		yearlySalesLabel = Arrays.asList("May","June","July","August","September","October","November","December");
		yearlySalesLabelList.addAll(yearlySalesLabel);
		chartData.setYearlySalesMonth(yearlySalesLabelList);
		ratingData = Arrays.asList(28, 35, 25, 7, 5);
		ratingDataList.addAll(ratingData);
		chartData.setRatingData(ratingDataList);
		
		System.out.println(chartData);
		
		return chartData;
		
		
//		System.out.println("print");
//		return null;
	    
	}

}
