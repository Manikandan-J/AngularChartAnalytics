package com.cts.gic.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cts.gic.customer.service.LOBInfoService;
import com.cts.gic.vo.SearchLOB;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class SearchController {
	
	@Autowired
	LOBInfoService lobInfoService;
	
	@GetMapping(value = "/searchLOB/{LOB}/{State}")
    public SearchLOB searchLOBData(@PathVariable("LOB") String lob,@PathVariable("State") String state) {
		
	return lobInfoService.searchLOBData(lob,state);
	
	}

}
