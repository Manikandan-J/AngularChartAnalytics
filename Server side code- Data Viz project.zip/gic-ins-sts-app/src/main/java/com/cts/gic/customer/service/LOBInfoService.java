package com.cts.gic.customer.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.cts.gic.vo.SearchLOB;

@Service
public class LOBInfoService {
	
	public SearchLOB searchLOBData(String lOB,String state)
	{
		List<SearchLOB> lobDataList = new ArrayList<>();
		lobDataList.add(new SearchLOB("Auto",45,55,35,44,4));
		lobDataList.add(new SearchLOB("Property",65,25,22,45,3));
		lobDataList.add(new SearchLOB("Marine",79,44,35,85,4));
		lobDataList.add(new SearchLOB("Farm",65,58,45,49,4));
		
		
		for(int i=0;i<lobDataList.size();i++)
		{
			if(lOB.equalsIgnoreCase(lobDataList.get(i).getLob()))
			{
			   return lobDataList.get(i);	
			}
		}
		return null;
		
		
	}

}
