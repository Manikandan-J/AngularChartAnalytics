package com.cts.gic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GicInsStsAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
