export class CustomerResponse
{
  contactName: string = '';
  mail: string = '';
  subject: string = '';
  message: string = '';
  
  constructor(contactName: string,mail: string,subject: string,message: string)
  {
    
    this.contactName = contactName;
    this.mail = mail;
    this.subject = subject;
    this.message = message;
  }

}