export class ChartData
{
   
    claimsData: number[] = [];
    claimsYear: string[] = [];
    productSalesYear: string[] = [];
    prodcutSalesData: number[] = [];
    yearlySalesMonth: string[] = [];
    yearlySalesData: number[] = [];
    ratingData: number[] = [];
    constructor(claimsYear: string[],claimsData: number[],productSalesYear:string[],prodcutSalesData:number[], yearlySalesMonth:string[], yearlySalesData: number[], ratingData: number[])
    {
     
      this.claimsData = claimsData.slice();
      this.claimsYear = claimsYear.slice();
      this.productSalesYear = productSalesYear.slice();
      this.prodcutSalesData = prodcutSalesData.slice();
      this.yearlySalesMonth = yearlySalesMonth.slice();
      this.yearlySalesData = yearlySalesData.slice();
      this.ratingData = ratingData.slice();

        
    }
}