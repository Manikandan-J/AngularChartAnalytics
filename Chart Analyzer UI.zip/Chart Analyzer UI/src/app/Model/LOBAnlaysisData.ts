export class LOBAnalysisData
{
   
   lob: String;
   
   perPolicyGrowth : number;
   perRenewal: number;
   perClaims: number;
   perNewCustomer: number;
   avgRating: number;
   constructor(lob: String,perPolicyGrowth: number,perRenewal: number,perClaims: number,perNewCustomer: number,avgRating: number)
   {
       this.lob = lob;
    //    this.state = state;
       this.perPolicyGrowth = perPolicyGrowth;
       this.perRenewal = perRenewal;
       this.perClaims = perClaims;
       this.perNewCustomer = perNewCustomer;
       this.avgRating = avgRating;
   }
}