import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { LOBAnalysisData } from '../Model/LOBAnlaysisData';
@Injectable({
  providedIn: 'root'
})
export class DataServiceService {
// data service for getting/seting role data
private role = new BehaviorSubject('null');
currentRole = this.role.asObservable();

setRole(role: string) {
  this.role.next(role);
}


// data service for set Target State
private targetState = new BehaviorSubject('No Data');
currentTargetState = this.targetState.asObservable();
setTargetState(targetState: string) {
  this.targetState.next(targetState);
}

// data service for set Target State
private targetLOB = new BehaviorSubject('No Data');
currentTargetLOB = this.targetLOB.asObservable();
setTargetLOB(targetLOB: string) {
  this.targetLOB.next(targetLOB);
}

// data service for set Source State
private sourceState = new BehaviorSubject('No Data');
currentSourceState = this.sourceState.asObservable();
setSourceState(sourceState: string) {
  this.sourceState.next(sourceState);
}


// data service for set Target State
private sourceLOB = new BehaviorSubject('No Data');
currentSourceLOB = this.sourceLOB.asObservable();
setSourceLOB(sourceLOB: string) {
  this.sourceLOB.next(sourceLOB);
}


  lobData1!: LOBAnalysisData;

private lobData = new BehaviorSubject(this.lobData1);
currentLOBData = this.lobData.asObservable();





  constructor() { }
}
