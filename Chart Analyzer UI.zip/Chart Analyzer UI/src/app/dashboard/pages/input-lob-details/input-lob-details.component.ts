import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LOBAnalysisData } from 'src/app/Model/LOBAnlaysisData';
import { DataServiceService } from 'src/app/service/data-service.service';
import { SendMailService } from 'src/app/service/send-mail.service';
@Component({
  selector: 'app-input-lob-details',
  templateUrl: './input-lob-details.component.html',
  styleUrls: ['./input-lob-details.component.css']
})
export class InputLobDetailsComponent implements OnInit {

  constructor(private router: Router,private dataService:DataServiceService,private searchService: SendMailService) { }
  role: string = '';
  show: boolean = true;
  logOffSwitch: boolean = false;
  targetState: string = '';
  targetLOB: string = '';
  sourceState: string = '';
  sourceLOB: string = '';
  lobData : LOBAnalysisData | undefined
  ngOnInit(): void {
    this.dataService.currentRole.subscribe(role => this.role =role);
     this.toggleAgentView();
  }
  onSubmit()
  {
    this.dataService.setTargetLOB(this.targetLOB);
    this.dataService.setTargetState(this.targetState);
    this.dataService.setSourceLOB(this.sourceLOB);
    this.dataService.setSourceState(this.targetState);
    //  this.searchService.searchLOB(this.targetLOB,this.targetState).subscribe(data =>this.lobData = data);
    this.router.navigate(['/Dashboard/LOB-Analysis-report']);
  }
  toggleAgentView()
  {
      if(this.role=='agent')
      {
        this.show = false;
        this.logOffSwitch = true;
      }
  }
  logOff()
  {
    this.router.navigate(['']);
  }

}
