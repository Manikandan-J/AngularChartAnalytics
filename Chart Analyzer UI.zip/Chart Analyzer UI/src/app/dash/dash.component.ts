import { Component } from '@angular/core';
import { map } from 'rxjs/operators';
import { Breakpoints, BreakpointObserver } from '@angular/cdk/layout';
import { DataServiceService } from '../service/data-service.service';
import { SendMailService } from '../service/send-mail.service';
import { LOBAnalysisData } from '../Model/LOBAnlaysisData';
import { Router, ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-dash',
  templateUrl: './dash.component.html',
  styleUrls: ['./dash.component.css']
})
export class DashComponent {
  columns: number;
  cols: number;
  rows: number; 
  targetState: string = 'no data';
  targetLOB: string = 'no data';
  lobData: LOBAnalysisData = new LOBAnalysisData('',0,0,0,0,0);
  constructor(private breakpointObserver: BreakpointObserver,private _activatedRoute: ActivatedRoute,private dataService: DataServiceService,private mailService: SendMailService) {
    this.columns = 0;
    this.cols = 0;
    this.rows = 0;
  }

   ngOnInit()
   {
    this._activatedRoute.params.subscribe(data => 
      {
        this.targetLOB = data.lob,
        this.targetState = data.state,
        
        console.log('from dash'+this.targetLOB +"KKKKKKKKKK");
      }
      
      
    )
    this.dataService.setTargetLOB( this.targetLOB);
        this.dataService.setTargetState(this.targetState);
    if(this.targetLOB == ''&& this.targetState == '')
    {
      
      this.mailService.searchLOB(this.targetLOB,this.targetState).subscribe(data =>this.lobData = data);

    }
    this.mailService.searchLOB(this.targetLOB,this.targetState).subscribe(data =>this.lobData = data);
   }
  //defaultValue:string = '';
 
  /** Based on the screen size, switch from standard to one column per row */
  cardLayout = this.breakpointObserver.observe(Breakpoints.Handset).pipe(
    map(({ matches }) => {      
      if (matches) {        
        return {
          columns: 1,          
          miniCard: { cols: 1, rows: 1 },
          chart: { cols: 1, rows: 2 },
          table: { cols: 1, rows: 4 },
          contactCard: { cols: 1, rows: 1}
        };
      }

      return {
       columns: 8,
       miniCard: { cols: 1, rows: 1 },
       chart: { cols: 4, rows: 4 },
       table: { cols: 4, rows: 2 }//,
       //contactCard: { cols: 2, rows: 2}
      };
    })
  );

  
    sendFeedback(){
      //this.defaultValue = '';      
    }
}
