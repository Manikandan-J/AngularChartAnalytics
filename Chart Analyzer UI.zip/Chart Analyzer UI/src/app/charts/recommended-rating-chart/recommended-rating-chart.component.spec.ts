import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RecommendedRatingChartComponent } from './recommended-rating-chart.component';

describe('RecommendedRatingChartComponent', () => {
  let component: RecommendedRatingChartComponent;
  let fixture: ComponentFixture<RecommendedRatingChartComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RecommendedRatingChartComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RecommendedRatingChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
