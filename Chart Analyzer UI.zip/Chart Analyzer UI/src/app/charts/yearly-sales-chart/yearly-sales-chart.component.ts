import { Component, OnInit } from '@angular/core';
import { ChartDataSets, ChartOptions, ChartType } from 'chart.js';
import { Color, Label } from 'ng2-charts';
import { ChartDataService } from 'src/app/service/chart-data.service';

@Component({
  selector: 'app-yearly-sales-chart',
  templateUrl: './yearly-sales-chart.component.html',
  styleUrls: ['./yearly-sales-chart.component.css']
})
export class YearlySalesChartComponent implements OnInit {

  public lineChartData: ChartDataSets[] = [
    { data: [55, 59, 67, 65, 60, 65, 72], label: 'SALES %', borderWidth: 1 }
  ];
  public lineChartLabels: Label[] = [];
  public lineChartOptions: ChartOptions = {
    responsive: true,
  };
  public lineChartColors: Color[] = [
    {
      borderColor: 'black',
      backgroundColor: 'LimeGreen',
    },
  ];
  public lineChartLegend = true;
  public lineChartType: ChartType = 'line';
  public lineChartPlugins = [];

  constructor(private chartDataService: ChartDataService) { }

  ngOnInit() {
    this.chartDataService.currentyearlySalesData.subscribe((data)=>
    {
      this.lineChartData[0].data = data.slice();
    });
    this.chartDataService.currentYearlySalesLabel.subscribe((data)=>
    {
      this.lineChartLabels = data.slice();
    });
    
  }

}
