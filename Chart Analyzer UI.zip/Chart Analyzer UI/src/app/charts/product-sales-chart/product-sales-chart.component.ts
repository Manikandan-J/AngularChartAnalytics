import { Component, OnInit } from '@angular/core';
import { ChartDataSets, ChartOptions, ChartType } from 'chart.js';
import { Color, Label } from 'ng2-charts';
import { ChartDataService } from 'src/app/service/chart-data.service';

@Component({
  selector: 'app-product-sales-chart',
  templateUrl: './product-sales-chart.component.html',
  styleUrls: ['./product-sales-chart.component.css']
})
export class ProductSalesChartComponent implements OnInit {

  public radarChartOptions: ChartOptions = {
    responsive: true,
  };
  public radarChartLabels: Label[] = [];

  public radarChartData: ChartDataSets[] = [
    { data: [], label: 'SALES %', borderWidth: 1 }
  ];
  public radarChartType: ChartType = 'radar';

  public radarChartColors: Color[] = [
    {
      borderColor: 'black',
      backgroundColor: 'MediumBlue',
    }
  ];

  constructor(private chartDataService: ChartDataService) { }

  ngOnInit() {

    this.chartDataService.currentProductSalesData.subscribe((data) =>
      {
        this.radarChartData[0].data = data.slice();
      }
      );

      this.chartDataService.currentProductSalesLabel.subscribe((data)=>
      {
        this.radarChartLabels = data.slice();
      })
  }

}
